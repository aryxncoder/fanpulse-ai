import { useState } from 'react';

const EMPTY = {
  title: '', team1: '', team2: '', batting: '1',
  runs: '0', wickets: '0', overs: '0', totalOvers: '20',
  target: '', venue: '', status: 'live',
};

function fromMatch(m) {
  return {
    title: m.title, team1: m.team1, team2: m.team2,
    batting: m.battingTeam === m.team2 ? '2' : '1',
    runs: String(m.runs), wickets: String(m.wickets), overs: String(m.overs),
    totalOvers: String(m.totalOvers), target: m.target ? String(m.target) : '',
    venue: m.venue || '', status: m.status,
  };
}

// Checks the form before sending. The server validates again as the final safety net.
function check(f) {
  const e = [];
  const num = (v) => (v === '' ? NaN : Number(v));
  if (!f.title.trim()) e.push('Enter a match title.');
  if (!f.team1.trim() || !f.team2.trim()) e.push('Enter both team names.');
  else if (f.team1.trim().toLowerCase() === f.team2.trim().toLowerCase()) e.push('Team names must be different.');
  const total = num(f.totalOvers);
  if (!Number.isInteger(total) || total < 1 || total > 50) e.push('Total overs must be a whole number from 1 to 50.');
  const runs = num(f.runs);
  if (!Number.isInteger(runs) || runs < 0) e.push('Runs must be 0 or more.');
  const wk = num(f.wickets);
  if (!Number.isInteger(wk) || wk < 0 || wk > 10) e.push('Wickets must be between 0 and 10.');
  const overs = num(f.overs);
  const balls = Math.round((overs - Math.floor(overs)) * 10);
  if (Number.isNaN(overs) || overs < 0 || balls > 5) e.push('Overs must look like 12 or 12.3 (balls go up to .5).');
  else if (overs > total) e.push('Overs cannot be more than total overs.');
  if (f.target !== '' && (!Number.isInteger(num(f.target)) || num(f.target) < 1)) e.push('Target must be a whole number, or left empty.');
  return e;
}

export default function MatchForm({ match, onSave, onCancel }) {
  const [form, setForm] = useState(match ? fromMatch(match) : EMPTY);
  const [errors, setErrors] = useState([]);
  const [busy, setBusy] = useState(false);
  const editing = Boolean(match);

  function update(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function submit(e) {
    e.preventDefault();
    const problems = check(form);
    if (problems.length) return setErrors(problems);

    const payload = {
      title: form.title,
      team1: form.team1,
      team2: form.team2,
      battingTeam: form.batting === '1' ? form.team1 : form.team2,
      runs: Number(form.runs),
      wickets: Number(form.wickets),
      overs: Number(form.overs),
      totalOvers: Number(form.totalOvers),
      target: form.target === '' ? null : Number(form.target),
      venue: form.venue,
      status: form.status,
    };

    setBusy(true);
    setErrors([]);
    try {
      await onSave(payload);
      if (!editing) setForm(EMPTY);
    } catch (err) {
      setErrors([err.message]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="card" aria-label="Match form">
      <h2>{editing ? 'Edit match' : 'Save a match'}</h2>
      <form className="stack" onSubmit={submit} noValidate>
        <label>
          Match title
          <input name="title" value={form.title} onChange={update} maxLength={80} />
        </label>
        <div className="row">
          <label>
            Team 1
            <input name="team1" value={form.team1} onChange={update} maxLength={40} />
          </label>
          <label>
            Team 2
            <input name="team2" value={form.team2} onChange={update} maxLength={40} />
          </label>
        </div>
        <label>
          Batting now
          <select name="batting" value={form.batting} onChange={update}>
            <option value="1">{form.team1 || 'Team 1'}</option>
            <option value="2">{form.team2 || 'Team 2'}</option>
          </select>
        </label>
        <div className="row three">
          <label>
            Runs
            <input name="runs" type="number" min="0" value={form.runs} onChange={update} />
          </label>
          <label>
            Wickets
            <input name="wickets" type="number" min="0" max="10" value={form.wickets} onChange={update} />
          </label>
          <label>
            Overs
            <input name="overs" type="number" min="0" step="0.1" value={form.overs} onChange={update} />
          </label>
        </div>
        <div className="row three">
          <label>
            Total overs
            <input name="totalOvers" type="number" min="1" max="50" value={form.totalOvers} onChange={update} />
          </label>
          <label>
            Target (optional)
            <input name="target" type="number" min="1" value={form.target} onChange={update} />
          </label>
          <label>
            Status
            <select name="status" value={form.status} onChange={update}>
              <option value="upcoming">Upcoming</option>
              <option value="live">Live</option>
              <option value="completed">Completed</option>
            </select>
          </label>
        </div>
        <label>
          Venue (optional)
          <input name="venue" value={form.venue} onChange={update} maxLength={80} />
        </label>

        {errors.length > 0 && (
          <div className="alert" role="alert">
            {errors.map((msg) => <p key={msg}>{msg}</p>)}
          </div>
        )}

        <div className="row buttons">
          <button className="btn primary" disabled={busy}>
            {busy ? 'Saving...' : editing ? 'Save changes' : 'Save match'}
          </button>
          {editing && (
            <button type="button" className="btn ghost" onClick={onCancel}>Cancel</button>
          )}
        </div>
      </form>
    </section>
  );
}
