import { useState } from 'react';
import { useAuth } from '../AuthContext.jsx';

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function AuthPanel() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState([]);
  const [busy, setBusy] = useState(false);

  const isRegister = mode === 'register';

  function update(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function switchMode() {
    setMode(isRegister ? 'login' : 'register');
    setErrors([]);
  }

  async function submit(e) {
    e.preventDefault();
    const problems = [];
    if (isRegister && form.name.trim().length < 2) problems.push('Enter your name (at least 2 characters).');
    if (!EMAIL_REGEX.test(form.email.trim())) problems.push('Enter a valid email address.');
    if (form.password.length < 6) problems.push('Password must be at least 6 characters.');
    if (problems.length) return setErrors(problems);

    setBusy(true);
    setErrors([]);
    try {
      if (isRegister) await register(form);
      else await login({ email: form.email, password: form.password });
    } catch (err) {
      setErrors([err.message]);
      setBusy(false);
    }
  }

  return (
    <section className="card" aria-label="Log in or register">
      <h2>{isRegister ? 'Create your account' : 'Log in to save matches'}</h2>
      <form className="stack" onSubmit={submit} noValidate>
        {isRegister && (
          <label>
            Name
            <input name="name" value={form.name} onChange={update} autoComplete="name" />
          </label>
        )}
        <label>
          Email
          <input name="email" type="email" value={form.email} onChange={update} autoComplete="email" />
        </label>
        <label>
          Password
          <input
            name="password"
            type="password"
            value={form.password}
            onChange={update}
            autoComplete={isRegister ? 'new-password' : 'current-password'}
          />
        </label>

        {errors.length > 0 && (
          <div className="alert" role="alert">
            {errors.map((msg) => <p key={msg}>{msg}</p>)}
          </div>
        )}

        <button className="btn primary" disabled={busy}>
          {busy ? 'Please wait...' : isRegister ? 'Register' : 'Log in'}
        </button>
      </form>
      <button className="link-btn" type="button" onClick={switchMode}>
        {isRegister ? 'Already have an account? Log in' : 'New here? Create an account'}
      </button>
    </section>
  );
}
