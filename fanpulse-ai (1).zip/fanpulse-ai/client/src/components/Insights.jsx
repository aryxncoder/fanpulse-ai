import { useEffect, useState } from 'react';
import { request } from '../api.js';

const FIELDS = ['title', 'team1', 'team2', 'battingTeam', 'runs', 'wickets', 'overs', 'totalOvers', 'target', 'venue', 'status'];

export default function Insights({ match }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  // Re-fetch only when the match numbers actually change.
  const key = JSON.stringify(FIELDS.reduce((o, f) => ({ ...o, [f]: match[f] }), {}));

  useEffect(() => {
    let cancelled = false;
    setError('');
    request('/insights', { method: 'POST', body: JSON.parse(key) })
      .then((res) => !cancelled && setData(res))
      .catch((err) => {
        if (!cancelled) {
          setData(null);
          setError(err.message);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [key]);

  if (error) return <section className="card"><p className="alert" role="alert">{error}</p></section>;
  if (!data) return <section className="card"><p className="muted">Loading insights...</p></section>;

  const { stats, insights } = data;
  const tiles = [
    ['Run rate', stats.currentRunRate],
    stats.requiredRunRate !== null ? ['Required rate', stats.requiredRunRate] : null,
    stats.projectedScore !== null ? ['Projected score', stats.projectedScore] : null,
    ['Wickets in hand', stats.wicketsInHand],
    ['Overs left', stats.oversLeft],
  ].filter(Boolean);

  return (
    <section className="card" aria-label="Match insights">
      <h2>What the numbers mean</h2>
      <div className="tiles">
        {tiles.map(([label, value]) => (
          <div className="tile" key={label}>
            <span className="tile-value">{value}</span>
            <span className="tile-label">{label}</span>
          </div>
        ))}
      </div>
      <ul className="insight-list">
        {insights.map((item) => (
          <li key={item.title}>
            <strong>{item.title}</strong>
            <p>{item.text}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
