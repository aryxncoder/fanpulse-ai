export default function MatchList({ matches, loading, selectedId, onSelect, onEdit, onDelete }) {
  return (
    <section className="card" aria-label="Saved matches">
      <h2>Your saved matches</h2>
      {loading && <p className="muted">Loading your matches...</p>}
      {!loading && matches.length === 0 && (
        <p className="muted">No matches yet. Fill in the form above to save your first one.</p>
      )}
      <ul className="match-list">
        {matches.map((m) => (
          <li key={m._id} className={m._id === selectedId ? 'active' : ''}>
            <button className="match-pick" onClick={() => onSelect(m._id)}>
              <strong>{m.title}</strong>
              <span className="muted">
                {m.battingTeam} {m.runs}/{m.wickets} ({m.overs} ov), {m.status}
              </span>
            </button>
            <div className="match-actions">
              <button className="btn ghost small" onClick={() => onEdit(m)}>Edit</button>
              <button className="btn danger small" onClick={() => onDelete(m._id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
