export default function Scoreboard({ match, isDemo }) {
  const bowling = match.battingTeam === match.team1 ? match.team2 : match.team1;
  const needed = match.target ? Math.max(match.target - match.runs, 0) : null;

  return (
    <section className="card scoreboard" aria-label="Scoreboard">
      <div className="sb-head">
        <span className={`badge ${match.status}`}>{match.status === 'live' ? 'Live' : match.status}</span>
        {isDemo && <span className="badge demo">Demo match</span>}
      </div>

      <h1 className="match-title">{match.title}</h1>
      {match.venue && <p className="muted">{match.venue}</p>}

      <div className="sb-body">
        <div className="batting">
          <span className="team-name">{match.battingTeam} batting</span>
          <span className="score">
            {match.runs}
            <span className="score-wkts">/{match.wickets}</span>
          </span>
          <span className="muted">
            {match.overs} of {match.totalOvers} overs
          </span>
        </div>
        <div className="bowling">
          <span className="team-name">{bowling}</span>
          <span className="muted">bowling</span>
        </div>
      </div>

      {match.target && (
        <p className="chase-line">
          Target {match.target}.{' '}
          {needed > 0 ? `${match.battingTeam} need ${needed} more runs.` : `${match.battingTeam} have reached the target.`}
        </p>
      )}
    </section>
  );
}
