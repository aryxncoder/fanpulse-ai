import { useEffect, useState } from 'react';
import { request } from '../api.js';

export default function Explainer() {
  const [topics, setTopics] = useState([]);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    request('/explain')
      .then((data) => setTopics(data.topics))
      .catch((err) => setError(err.message));
  }, []);

  async function ask(text) {
    const q = text.trim();
    if (!q) {
      setError('Type a question or pick a topic.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      setAnswer(await request('/explain', { method: 'POST', body: { question: q } }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  function submit(e) {
    e.preventDefault();
    ask(question);
  }

  return (
    <section className="card" aria-label="Cricket explainer">
      <h2>New to cricket? Ask here</h2>
      <p className="muted">Pick a topic or type a question, like "what is the required run rate?"</p>

      <div className="chips">
        {topics.map((t) => (
          <button
            key={t.topic}
            type="button"
            className="chip"
            onClick={() => {
              setQuestion(t.title);
              ask(t.title);
            }}
          >
            {t.title}
          </button>
        ))}
      </div>

      <form className="inline-form" onSubmit={submit}>
        <label className="sr-only" htmlFor="question">Your question</label>
        <input
          id="question"
          value={question}
          maxLength={200}
          placeholder="Ask about a cricket term"
          onChange={(e) => setQuestion(e.target.value)}
        />
        <button className="btn" disabled={busy}>{busy ? 'Looking...' : 'Explain'}</button>
      </form>

      {error && <p className="alert" role="alert">{error}</p>}
      {answer && (
        <div className="answer" aria-live="polite">
          <strong>{answer.title}</strong>
          <p>{answer.answer}</p>
          {answer.example && <p className="muted">Example: {answer.example}</p>}
        </div>
      )}
    </section>
  );
}
