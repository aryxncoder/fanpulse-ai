import { useEffect, useState } from 'react';
import { useAuth } from './AuthContext.jsx';
import { request } from './api.js';
import Scoreboard from './components/Scoreboard.jsx';
import Insights from './components/Insights.jsx';
import Explainer from './components/Explainer.jsx';
import AuthPanel from './components/AuthPanel.jsx';
import MatchForm from './components/MatchForm.jsx';
import MatchList from './components/MatchList.jsx';

// Shown to everyone, so the dashboard is useful before logging in.
const DEMO_MATCH = {
  _id: 'demo',
  title: 'Chennai Kings vs Mumbai Waves',
  team1: 'Chennai Kings',
  team2: 'Mumbai Waves',
  battingTeam: 'Mumbai Waves',
  runs: 112,
  wickets: 3,
  overs: 13.2,
  totalOvers: 20,
  target: 178,
  venue: 'Chepauk Stadium',
  status: 'live',
};

export default function App() {
  const { user, token, checking, logout } = useAuth();
  const [matches, setMatches] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Load saved matches whenever someone logs in; clear them on logout.
  useEffect(() => {
    if (!user) {
      setMatches([]);
      setSelectedId(null);
      setEditing(null);
      return;
    }
    setLoading(true);
    setError('');
    request('/matches', { token })
      .then((data) => setMatches(data.matches))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [user, token]);

  const selected = matches.find((m) => m._id === selectedId);
  const match = selected || DEMO_MATCH;

  async function handleSave(payload) {
    if (editing) {
      const data = await request(`/matches/${editing._id}`, { method: 'PUT', body: payload, token });
      setMatches((list) => list.map((m) => (m._id === data.match._id ? data.match : m)));
      setSelectedId(data.match._id);
      setEditing(null);
    } else {
      const data = await request('/matches', { method: 'POST', body: payload, token });
      setMatches((list) => [data.match, ...list]);
      setSelectedId(data.match._id);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm('Delete this saved match?')) return;
    setError('');
    try {
      await request(`/matches/${id}`, { method: 'DELETE', token });
      setMatches((list) => list.filter((m) => m._id !== id));
      if (selectedId === id) setSelectedId(null);
      if (editing && editing._id === id) setEditing(null);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true" />
          <span className="brand-name">FanPulse AI</span>
        </div>
        {user && (
          <div className="user-box">
            <span className="muted">Signed in as {user.name}</span>
            <button className="btn ghost" onClick={logout}>Log out</button>
          </div>
        )}
      </header>

      <main className="layout">
        <div className="main-col">
          <Scoreboard match={match} isDemo={!selected} />
          <Insights match={match} />
          <Explainer />
        </div>

        <aside className="side-col">
          {checking ? (
            <section className="card"><p className="muted">Checking your session...</p></section>
          ) : !user ? (
            <AuthPanel />
          ) : (
            <>
              {error && <p className="alert" role="alert">{error}</p>}
              <MatchForm
                key={editing ? editing._id : 'new'}
                match={editing}
                onSave={handleSave}
                onCancel={() => setEditing(null)}
              />
              <MatchList
                matches={matches}
                loading={loading}
                selectedId={selectedId}
                onSelect={setSelectedId}
                onEdit={setEditing}
                onDelete={handleDelete}
              />
            </>
          )}
        </aside>
      </main>
    </div>
  );
}
