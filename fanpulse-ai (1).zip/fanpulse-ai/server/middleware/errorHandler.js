// 404 for unknown routes
function notFound(req, res) {
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` });
}

// One place that turns any error into a clean JSON response
function errorHandler(err, req, res, next) {
  let status = err.status || err.statusCode || 500;
  let message = err.message || 'Server error';

  if (err.type === 'entity.parse.failed') {
    status = 400;
    message = 'Request body is not valid JSON';
  } else if (err.name === 'ValidationError') {
    status = 400;
    message = Object.values(err.errors).map((e) => e.message).join('. ');
  } else if (err.code === 11000) {
    status = 409;
    message = 'That email is already registered';
  }

  if (status >= 500) {
    console.error(err);
    message = 'Something went wrong on the server. Please try again';
  }

  res.status(status).json({ message });
}

module.exports = { notFound, errorHandler };
