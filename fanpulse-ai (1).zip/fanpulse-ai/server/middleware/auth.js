const jwt = require('jsonwebtoken');

// Protects a route: expects "Authorization: Bearer <token>".
// On success it sets req.userId and calls next().
function protect(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ message: 'Please log in to continue' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Your session has expired. Please log in again' });
  }
}

module.exports = protect;
