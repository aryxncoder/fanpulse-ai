// Entry point: load env vars, connect to MongoDB, then start the HTTP server.
require('dotenv').config();

const connectDB = require('./config/db');
const app = require('./app');

const PORT = process.env.PORT || 5000;

async function start() {
  if (!process.env.MONGO_URI || !process.env.JWT_SECRET) {
    console.error('Missing MONGO_URI or JWT_SECRET. Copy .env.example to .env and fill it in.');
    process.exit(1);
  }
  try {
    await connectDB();
    app.listen(PORT, () => console.log(`FanPulse API running on http://localhost:${PORT}`));
  } catch (err) {
    console.error('Could not connect to MongoDB:', err.message);
    process.exit(1);
  }
}

start();
