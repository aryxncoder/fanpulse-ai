const mongoose = require('mongoose');

const matchSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: true, trim: true, maxlength: 80 },
    team1: { type: String, required: true, trim: true, maxlength: 40 },
    team2: { type: String, required: true, trim: true, maxlength: 40 },
    battingTeam: { type: String, required: true, trim: true, maxlength: 40 },
    runs: { type: Number, required: true, min: 0, default: 0 },
    wickets: { type: Number, required: true, min: 0, max: 10, default: 0 },
    overs: { type: Number, required: true, min: 0, default: 0 }, // 12.3 = 12 overs and 3 balls
    totalOvers: { type: Number, required: true, min: 1, max: 50, default: 20 },
    target: { type: Number, min: 1, default: null }, // runs needed to win (second innings only)
    venue: { type: String, trim: true, maxlength: 80, default: '' },
    status: { type: String, enum: ['upcoming', 'live', 'completed'], default: 'live' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Match', matchSchema);
