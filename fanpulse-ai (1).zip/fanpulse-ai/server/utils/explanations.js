// Predefined beginner-friendly answers. No paid AI API is used.
const explanations = [
  {
    topic: 'run-rate',
    title: 'Run rate',
    keywords: ['run rate', 'crr', 'scoring rate'],
    answer: 'Run rate is the average number of runs a team scores per over. You get it by dividing total runs by overs faced.',
    example: '60 runs after 10 overs is a run rate of 6.00.',
  },
  {
    topic: 'required-run-rate',
    title: 'Required run rate',
    keywords: ['required run rate', 'required rate', 'required', 'rrr', 'need to score'],
    answer: 'Required run rate is how many runs per over the chasing team must score from now on to win. If it is higher than the current run rate, the team is behind.',
    example: 'Need 48 runs from 4 overs, so required rate = 12.00 per over.',
  },
  {
    topic: 'overs',
    title: 'Overs',
    keywords: ['over', 'overs', 'balls'],
    answer: 'An over is 6 legal balls bowled by one bowler. The number after the dot counts balls, so 12.3 means 12 overs and 3 balls. It never goes above .5.',
    example: '12.5 is followed by 13.0, not 12.6.',
  },
  {
    topic: 'wickets',
    title: 'Wickets',
    keywords: ['wicket', 'out', 'all out', 'dismissal'],
    answer: 'A wicket falls when a batter is dismissed (bowled, caught, run out and so on). A team has 10 wickets, and the innings ends when 10 have fallen or the overs run out.',
    example: 'A score of 112/3 means 112 runs for the loss of 3 wickets.',
  },
  {
    topic: 'powerplay',
    title: 'Powerplay',
    keywords: ['powerplay', 'power play', 'fielding restriction'],
    answer: 'In the powerplay overs, only a limited number of fielders may stand far from the batter. That makes boundaries easier, so teams often score quickly. In T20 it is the first 6 overs.',
    example: 'A team scoring 55/1 after 6 overs had a strong powerplay.',
  },
  {
    topic: 'strike-rate',
    title: 'Strike rate',
    keywords: ['strike rate', 'sr'],
    answer: 'Strike rate shows how fast a batter scores: runs per 100 balls faced. Higher means quicker scoring.',
    example: '30 runs from 20 balls is a strike rate of 150.',
  },
  {
    topic: 'economy',
    title: 'Economy rate',
    keywords: ['economy', 'bowler runs'],
    answer: 'Economy rate is how many runs a bowler concedes per over on average. Lower is better for the bowler.',
    example: '24 runs conceded in 4 overs is an economy of 6.00.',
  },
  {
    topic: 'extras',
    title: 'Wides and no-balls',
    keywords: ['wide', 'no ball', 'no-ball', 'extras', 'free hit'],
    answer: 'A wide or a no-ball gives the batting team a run and must be bowled again. After a no-ball in white-ball cricket, the next ball is a free hit, where the batter can only be out run out.',
    example: 'A wide ball adds 1 run to the score but does not count as one of the 6 balls.',
  },
  {
    topic: 'drs',
    title: 'DRS (Decision Review System)',
    keywords: ['drs', 'review', 'third umpire'],
    answer: 'DRS lets teams ask the third umpire to check an on-field decision using ball tracking and replays. Each team has a limited number of reviews. They keep a review if the original decision is overturned.',
    example: 'A batter given out lbw can review to check if the ball was really hitting the stumps.',
  },
  {
    topic: 'dls',
    title: 'Duckworth-Lewis-Stern (DLS)',
    keywords: ['dls', 'duckworth', 'rain', 'par score'],
    answer: 'When rain cuts a match short, DLS sets a fair new target by considering overs lost and wickets in hand. It is why a chasing team can get a changed target.',
    example: 'After a rain break, a chasing team may be asked to score 150 from 15 overs instead of 180 from 20.',
  },
];

module.exports = explanations;
