// Validation for match data. Returns { errors: [...], value: {...clean data} }.
function toNumber(v) {
  if (v === undefined || v === null || v === '') return undefined;
  const n = Number(v);
  return Number.isFinite(n) ? n : NaN;
}

function validateMatch(body) {
  const b = body || {};
  const errors = [];
  const text = (v) => (typeof v === 'string' ? v.trim() : '');

  const title = text(b.title);
  const team1 = text(b.team1);
  const team2 = text(b.team2);
  const battingTeam = text(b.battingTeam);
  const venue = text(b.venue);

  if (!title || title.length > 80) errors.push('Title is required (max 80 characters).');
  if (!team1 || team1.length > 40) errors.push('Team 1 is required (max 40 characters).');
  if (!team2 || team2.length > 40) errors.push('Team 2 is required (max 40 characters).');
  if (team1 && team2 && team1.toLowerCase() === team2.toLowerCase()) {
    errors.push('The two team names must be different.');
  }
  if (!battingTeam || (battingTeam !== team1 && battingTeam !== team2)) {
    errors.push('Batting team must be one of the two teams.');
  }
  if (venue.length > 80) errors.push('Venue must be 80 characters or fewer.');

  const totalRaw = toNumber(b.totalOvers);
  const totalOvers = totalRaw === undefined ? 20 : totalRaw;
  const totalOk = Number.isInteger(totalOvers) && totalOvers >= 1 && totalOvers <= 50;
  if (!totalOk) errors.push('Total overs must be a whole number from 1 to 50.');

  const runs = toNumber(b.runs);
  if (runs === undefined || !Number.isInteger(runs) || runs < 0 || runs > 999) {
    errors.push('Runs must be a whole number from 0 to 999.');
  }

  const wickets = toNumber(b.wickets);
  if (wickets === undefined || !Number.isInteger(wickets) || wickets < 0 || wickets > 10) {
    errors.push('Wickets must be a whole number from 0 to 10.');
  }

  const overs = toNumber(b.overs);
  if (overs === undefined || Number.isNaN(overs) || overs < 0) {
    errors.push('Overs must be a number such as 12 or 12.3.');
  } else {
    const oneDecimal = Math.abs(overs * 10 - Math.round(overs * 10)) < 1e-9;
    const balls = Math.round((overs - Math.floor(overs)) * 10);
    if (!oneDecimal || balls > 5) {
      errors.push('Overs use balls after the dot, so 12.6 is not valid (use 12.0 to 12.5).');
    } else if (totalOk && overs > totalOvers) {
      errors.push('Overs cannot be more than the total overs.');
    }
  }

  let target = null;
  const targetRaw = toNumber(b.target);
  if (targetRaw !== undefined) {
    if (!Number.isInteger(targetRaw) || targetRaw < 1 || targetRaw > 1000) {
      errors.push('Target must be a whole number from 1 to 1000, or left empty.');
    } else {
      target = targetRaw;
    }
  }

  const status = b.status === undefined || b.status === '' ? 'live' : b.status;
  if (!['upcoming', 'live', 'completed'].includes(status)) {
    errors.push('Status must be upcoming, live or completed.');
  }

  return {
    errors,
    value: { title, team1, team2, battingTeam, venue, runs, wickets, overs, totalOvers, target, status },
  };
}

module.exports = { validateMatch };
