// Simple cricket maths + plain-English insights. No AI service needed.
const round2 = (n) => Math.round(n * 100) / 100;

// 12.3 overs = 12 overs and 3 balls = 75 balls
function oversToBalls(overs) {
  const whole = Math.floor(overs);
  const balls = Math.round((overs - whole) * 10);
  return whole * 6 + balls;
}

function ballsToOvers(balls) {
  return `${Math.floor(balls / 6)}.${balls % 6}`;
}

function runRate(runs, overs) {
  const balls = oversToBalls(overs);
  return balls === 0 ? 0 : round2(runs / (balls / 6));
}

function getPhase(balls, totalOvers) {
  const powerplayEnd = totalOvers <= 20 ? 6 : 10;
  const deathStart = totalOvers - (totalOvers <= 20 ? 4 : 10);
  const over = balls / 6;
  if (over < powerplayEnd) return 'Powerplay';
  if (over >= deathStart) return 'Death overs';
  return 'Middle overs';
}

const PHASE_TEXT = {
  Powerplay: 'Only two fielders are allowed outside the circle, so batters often attack here.',
  'Middle overs': 'Teams usually build partnerships and keep the scoreboard moving without losing wickets.',
  'Death overs': 'The final overs. Batters swing hard, and bowlers try yorkers and slower balls.',
};

function buildInsights(match) {
  const { runs, wickets, overs, totalOvers, target, battingTeam } = match;
  const balls = oversToBalls(overs);
  const ballsLeft = totalOvers * 6 - balls;
  const currentRunRate = runRate(runs, overs);
  const wicketsInHand = 10 - wickets;
  const phase = getPhase(balls, totalOvers);

  const stats = {
    currentRunRate,
    wicketsInHand,
    phase,
    oversLeft: ballsToOvers(Math.max(ballsLeft, 0)),
    projectedScore: null,
    runsNeeded: null,
    requiredRunRate: null,
  };
  const insights = [];

  insights.push({
    title: 'Run rate',
    text:
      balls === 0
        ? 'The innings has not started, so there is no run rate yet.'
        : `${battingTeam} are scoring ${currentRunRate} runs per over. Run rate is total runs divided by overs faced.`,
  });

  if (target) {
    const runsNeeded = target - runs;
    stats.runsNeeded = Math.max(runsNeeded, 0);

    if (runsNeeded <= 0) {
      insights.push({
        title: 'Chase result',
        text: `${battingTeam} have reached the target and win with ${wicketsInHand} wickets in hand.`,
      });
    } else if (wickets >= 10 || ballsLeft <= 0) {
      insights.push({
        title: 'Chase result',
        text:
          runsNeeded === 1
            ? 'The scores are level, so the match is tied. A Super Over may decide the winner.'
            : `${battingTeam} fell short and lose by ${runsNeeded - 1} runs.`,
      });
    } else {
      const requiredRunRate = round2(runsNeeded / (ballsLeft / 6));
      stats.requiredRunRate = requiredRunRate;
      const gap = round2(requiredRunRate - currentRunRate);
      let pressure;
      if (gap <= 0) pressure = 'They are ahead of the rate, so the chase is comfortable.';
      else if (gap <= 2) pressure = 'The chase is balanced and could swing either way.';
      else if (gap <= 4) pressure = 'The batting side is under pressure and needs to speed up.';
      else pressure = 'The required rate is very high, so the chase is difficult.';

      insights.push({
        title: 'The chase',
        text: `${battingTeam} need ${runsNeeded} runs from ${ballsLeft} balls. They must score ${requiredRunRate} per over (required rate) while scoring ${currentRunRate} so far. ${pressure}`,
      });
    }
  } else if (balls > 0) {
    const projectedScore = Math.round(currentRunRate * totalOvers);
    stats.projectedScore = projectedScore;
    insights.push({
      title: 'Projected score',
      text: `If ${battingTeam} keep this pace for all ${totalOvers} overs, they would finish around ${projectedScore}. It is only an estimate, because wickets and overs change the pace.`,
    });
  }

  let wicketText;
  if (wickets >= 10) wicketText = `${battingTeam} are all out.`;
  else if (wicketsInHand >= 7) wicketText = `${wicketsInHand} wickets in hand means the batters can take risks.`;
  else if (wicketsInHand >= 4) wicketText = `${wicketsInHand} wickets in hand is a balanced position.`;
  else wicketText = `Only ${wicketsInHand} wickets left, so the batters must be careful.`;
  insights.push({ title: 'Wickets', text: wicketText });

  if (balls > 0 && ballsLeft > 0) {
    insights.push({ title: phase, text: PHASE_TEXT[phase] });
  }

  return { stats, insights };
}

module.exports = { oversToBalls, ballsToOvers, runRate, getPhase, buildInsights };
