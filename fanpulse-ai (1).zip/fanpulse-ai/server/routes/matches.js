const express = require('express');
const mongoose = require('mongoose');
const Match = require('../models/Match');
const protect = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const { validateMatch } = require('../utils/validate');

const router = express.Router();

// Every match route needs a logged-in user, and users only see their own matches.
router.use(protect);

function checkId(req, res, next) {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({ message: 'Invalid match id' });
  }
  next();
}

// GET /api/matches
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const matches = await Match.find({ user: req.userId }).sort({ createdAt: -1 });
    res.json({ matches });
  })
);

// GET /api/matches/:id
router.get(
  '/:id',
  checkId,
  asyncHandler(async (req, res) => {
    const match = await Match.findOne({ _id: req.params.id, user: req.userId });
    if (!match) return res.status(404).json({ message: 'Match not found' });
    res.json({ match });
  })
);

// POST /api/matches
router.post(
  '/',
  asyncHandler(async (req, res) => {
    const { errors, value } = validateMatch(req.body);
    if (errors.length) return res.status(400).json({ message: errors.join(' '), errors });

    const match = await Match.create({ ...value, user: req.userId });
    res.status(201).json({ match });
  })
);

// PUT /api/matches/:id  (send the full match, same fields as POST)
router.put(
  '/:id',
  checkId,
  asyncHandler(async (req, res) => {
    const { errors, value } = validateMatch(req.body);
    if (errors.length) return res.status(400).json({ message: errors.join(' '), errors });

    const match = await Match.findOneAndUpdate({ _id: req.params.id, user: req.userId }, value, {
      new: true,
      runValidators: true,
    });
    if (!match) return res.status(404).json({ message: 'Match not found' });
    res.json({ match });
  })
);

// DELETE /api/matches/:id
router.delete(
  '/:id',
  checkId,
  asyncHandler(async (req, res) => {
    const match = await Match.findOneAndDelete({ _id: req.params.id, user: req.userId });
    if (!match) return res.status(404).json({ message: 'Match not found' });
    res.json({ message: 'Match deleted' });
  })
);

module.exports = router;
