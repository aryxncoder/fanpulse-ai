const express = require('express');
const { validateMatch } = require('../utils/validate');
const { buildInsights } = require('../utils/cricket');

const router = express.Router();

// POST /api/insights  (public) - send match numbers, get plain-English insights back.
// Works for the demo match and for saved matches alike.
router.post('/', (req, res) => {
  const { errors, value } = validateMatch(req.body);
  if (errors.length) return res.status(400).json({ message: errors.join(' '), errors });
  res.json(buildInsights(value));
});

module.exports = router;
