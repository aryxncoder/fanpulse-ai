const express = require('express');
const explanations = require('../utils/explanations');

const router = express.Router();

// Whole-word match, so "out" does not match inside "about"
function hasKeyword(text, keyword) {
  const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`\\b${escaped}\\b`).test(text);
}

// GET /api/explain - list the topics fans can ask about
router.get('/', (req, res) => {
  res.json({ topics: explanations.map(({ topic, title }) => ({ topic, title })) });
});

// POST /api/explain { question } - find the best predefined answer by keyword
router.post('/', (req, res) => {
  const question = typeof req.body.question === 'string' ? req.body.question.trim() : '';
  if (!question) return res.status(400).json({ message: 'Please type a question' });
  if (question.length > 200) return res.status(400).json({ message: 'Question must be 200 characters or fewer' });

  const q = question.toLowerCase();
  // Prefer the topic with the longest matching keyword (so "required run rate" beats "run rate")
  let best = null;
  let bestLen = 0;
  for (const item of explanations) {
    for (const kw of item.keywords) {
      if (hasKeyword(q, kw) && kw.length > bestLen) {
        best = item;
        bestLen = kw.length;
      }
    }
  }

  if (!best) {
    return res.json({
      matched: false,
      title: 'Not sure about that one',
      answer: `I only know a few cricket basics. Try asking about: ${explanations.map((e) => e.title.toLowerCase()).join(', ')}.`,
      example: '',
    });
  }
  res.json({ matched: true, topic: best.topic, title: best.title, answer: best.answer, example: best.example });
});

module.exports = router;
