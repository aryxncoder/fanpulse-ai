// Builds the Express app. Kept separate from server.js so tests can import it
// without opening a port or connecting to a database.
const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const matchRoutes = require('./routes/matches');
const explainRoutes = require('./routes/explain');
const insightRoutes = require('./routes/insights');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const app = express();

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.use('/api/auth', authRoutes);
app.use('/api/matches', matchRoutes);
app.use('/api/explain', explainRoutes);
app.use('/api/insights', insightRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
