// These tests need no database: they cover validation, auth guards and public routes.
process.env.JWT_SECRET = 'test-secret';

const test = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');
const jwt = require('jsonwebtoken');
const app = require('../app');
const protect = require('../middleware/auth');

test('GET /api/health returns ok', async () => {
  const res = await request(app).get('/api/health');
  assert.equal(res.status, 200);
  assert.equal(res.body.status, 'ok');
});

test('register rejects invalid input', async () => {
  const res = await request(app).post('/api/auth/register').send({ name: 'A', email: 'nope', password: '123' });
  assert.equal(res.status, 400);
  assert.equal(res.body.errors.length, 3);
});

test('login requires email and password', async () => {
  const res = await request(app).post('/api/auth/login').send({ email: 'a@b.com' });
  assert.equal(res.status, 400);
});

test('matches routes require a token', async () => {
  const res = await request(app).get('/api/matches');
  assert.equal(res.status, 401);
});

test('matches routes reject a bad token', async () => {
  const res = await request(app).get('/api/matches').set('Authorization', 'Bearer not-a-real-token');
  assert.equal(res.status, 401);
});

test('protect middleware accepts a valid token', () => {
  const token = jwt.sign({ id: 'user123' }, process.env.JWT_SECRET);
  const req = { headers: { authorization: `Bearer ${token}` } };
  let called = false;
  protect(req, {}, () => { called = true; });
  assert.ok(called);
  assert.equal(req.userId, 'user123');
});

test('POST /api/insights returns stats for a valid match', async () => {
  const res = await request(app).post('/api/insights').send({
    title: 'T', team1: 'A', team2: 'B', battingTeam: 'B', runs: 100, wickets: 2, overs: 12, totalOvers: 20, target: 170,
  });
  assert.equal(res.status, 200);
  assert.equal(res.body.stats.runsNeeded, 70);
});

test('POST /api/insights rejects invalid data', async () => {
  const res = await request(app).post('/api/insights').send({ title: '' });
  assert.equal(res.status, 400);
});

test('explain answers a known topic and handles unknown ones', async () => {
  const known = await request(app).post('/api/explain').send({ question: 'What is the required run rate?' });
  assert.equal(known.body.topic, 'required-run-rate');
  const unknown = await request(app).post('/api/explain').send({ question: 'banana' });
  assert.equal(unknown.body.matched, false);
  const empty = await request(app).post('/api/explain').send({ question: '' });
  assert.equal(empty.status, 400);
});

test('malformed JSON and unknown routes return clean errors', async () => {
  const bad = await request(app).post('/api/insights').set('Content-Type', 'application/json').send('{oops');
  assert.equal(bad.status, 400);
  const missing = await request(app).get('/api/nope');
  assert.equal(missing.status, 404);
});
