const test = require('node:test');
const assert = require('node:assert/strict');
const { oversToBalls, runRate, buildInsights } = require('../utils/cricket');

test('oversToBalls converts overs notation to balls', () => {
  assert.equal(oversToBalls(12.3), 75);
  assert.equal(oversToBalls(0), 0);
  assert.equal(oversToBalls(20), 120);
});

test('runRate divides runs by overs faced', () => {
  assert.equal(runRate(60, 10), 6);
  assert.equal(runRate(112, 13.2), 8.4);
  assert.equal(runRate(10, 0), 0);
});

test('buildInsights calculates the required run rate in a chase', () => {
  const { stats } = buildInsights({
    runs: 112, wickets: 3, overs: 13.2, totalOvers: 20, target: 178, battingTeam: 'A',
  });
  assert.equal(stats.runsNeeded, 66);
  assert.equal(stats.requiredRunRate, 9.9); // 66 runs from 40 balls
  assert.equal(stats.wicketsInHand, 7);
});

test('buildInsights projects a score when batting first', () => {
  const { stats } = buildInsights({
    runs: 60, wickets: 1, overs: 10, totalOvers: 20, target: null, battingTeam: 'A',
  });
  assert.equal(stats.projectedScore, 120);
});

test('buildInsights reports a finished chase', () => {
  const { insights } = buildInsights({
    runs: 180, wickets: 4, overs: 18.2, totalOvers: 20, target: 178, battingTeam: 'A',
  });
  assert.match(insights.find((i) => i.title === 'Chase result').text, /win/);
});
