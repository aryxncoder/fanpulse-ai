const test = require('node:test');
const assert = require('node:assert/strict');
const { validateMatch } = require('../utils/validate');

const good = {
  title: 'Final', team1: 'Lions', team2: 'Tigers', battingTeam: 'Lions',
  runs: '50', wickets: '2', overs: '6.4', totalOvers: '20', target: '', venue: 'Oval', status: 'live',
};

test('accepts a valid match and converts numbers', () => {
  const { errors, value } = validateMatch(good);
  assert.deepEqual(errors, []);
  assert.equal(value.runs, 50);
  assert.equal(value.target, null);
});

test('rejects invalid overs like 12.6', () => {
  assert.ok(validateMatch({ ...good, overs: '12.6' }).errors.length > 0);
});

test('rejects more than 10 wickets and negative runs', () => {
  assert.ok(validateMatch({ ...good, wickets: 11 }).errors.length > 0);
  assert.ok(validateMatch({ ...good, runs: -5 }).errors.length > 0);
});

test('rejects a batting team that is not playing', () => {
  assert.ok(validateMatch({ ...good, battingTeam: 'Bears' }).errors.length > 0);
});

test('rejects overs above total overs and missing body', () => {
  assert.ok(validateMatch({ ...good, overs: 21 }).errors.length > 0);
  assert.ok(validateMatch(undefined).errors.length > 0);
});
